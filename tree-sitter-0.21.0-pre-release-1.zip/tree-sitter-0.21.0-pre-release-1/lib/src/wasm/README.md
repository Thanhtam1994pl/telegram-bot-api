## WASM

The `wasm.h` header file contains a standard interface implemented by multiple WASM implementations. It was taken from here:

https://github.com/WebAssembly/wasm-c-api/blob/c9d31284651b975f05ac27cee0bab1377560b87e/include/wasm.h

The `wasmtime` headers were taken from here:

https://github.com/bytecodealliance/wasmtime/tree/main/crates/c-api/include/wasmtime